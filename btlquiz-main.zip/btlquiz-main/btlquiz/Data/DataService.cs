﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using btlquiz.Models;

namespace btlquiz.Data
{
    public static class DataService
    {
        private static readonly string quizFile = Path.Combine(Directory.GetCurrentDirectory(), "Data", "quiz.json");
        private static readonly string userFile = Path.Combine(Directory.GetCurrentDirectory(), "Data", "user.json");

        // Đọc danh sách bài quiz
        public static List<Quiz> GetAllQuizzes()
        {
            if (!File.Exists(quizFile)) return new List<Quiz>();

            string json = File.ReadAllText(quizFile);
            return JsonSerializer.Deserialize<List<Quiz>>(json) ?? new List<Quiz>();
        }

        // Trả về danh sách môn học duy nhất từ quiz.json
        public static List<string> GetAllSubjects()
        {
            var quizzes = GetAllQuizzes();
            return quizzes.Select(q => q.Subject).Distinct().ToList();
        }

        // Đọc thông tin user
        public static UserInfo GetUser()
        {
            if (!File.Exists(userFile))
                return new UserInfo { Username = "Unknown", Score = 0, Rank = "Bronze" };

            string json = File.ReadAllText(userFile);
            return JsonSerializer.Deserialize<UserInfo>(json) ?? new UserInfo { Username = "Unknown", Score = 0, Rank = "Bronze" };
        }

        // Ghi thông tin user (cập nhật điểm và rank)
        public static void SaveUser(UserInfo user)
        {
            string json = JsonSerializer.Serialize(user, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(userFile, json);
        }
    }
}
