﻿var builder = WebApplication.CreateBuilder(args);

// Add services
builder.Services.AddControllersWithViews();

var app = builder.Build();

// Configure middleware
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

// Cấu hình route mặc định dẫn đến QuizController - SelectSubject
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Quiz}/{action=SelectSubject}/{id?}");

app.Run();
