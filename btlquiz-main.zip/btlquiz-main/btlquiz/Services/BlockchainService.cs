﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using Nethereum.Web3;
using Nethereum.Web3.Accounts;
using Nethereum.JsonRpc.Client;
using Nethereum.Hex.HexTypes;
using System.Numerics;

namespace btlquiz.Services
{
    public class BlockchainService
    {
        private readonly Web3 _web3;
        private readonly string _contractAddress = "0xfe82714a426c23acbe73fa65a62bfdbda5459ee2";
        private readonly string _privateKey = "7290819ca45e17c2a4fba6506d2b35a8d32dc7e1a674c69697921b818e1e3729";
        private readonly string _accountAddress;

        public BlockchainService()
        {
            var account = new Account(_privateKey);
            _accountAddress = account.Address;

            var httpClient = new HttpClient();
            httpClient.Timeout = TimeSpan.FromSeconds(60);

            _web3 = new Web3(account, "https://sepolia.infura.io/v3/ed58fcded96d49ceb5cf946c083bc82a");
        }

        /// <summary>
        /// Gửi transaction để set thông tin player lên blockchain
        /// </summary>
        public async Task<string> SetPlayerAsync(string username, int score, string rank)
        {
            try
            {
                var contract = _web3.Eth.GetContract(ABI, _contractAddress);
                var setPlayerFunction = contract.GetFunction("setPlayer");

                // Lấy nonce mới nhất (bao gồm cả transaction đang chờ)
                var nonce = await _web3.Eth.Transactions.GetTransactionCount
                                        .SendRequestAsync(_accountAddress, Nethereum.RPC.Eth.DTOs.BlockParameter.CreatePending());

                // Ước lượng gas cho giao dịch
                var estimatedGas = await setPlayerFunction.EstimateGasAsync(_accountAddress, null, null, username, score, rank);

                // Gửi transaction với nonce cụ thể để tránh lỗi 'already known'
                var txHash = await setPlayerFunction.SendTransactionAsync(_accountAddress,
                                            estimatedGas,
                                            null,
                                            nonce,  // Truyền nonce ở đây
                                            username, score, rank);
                return txHash;
            }
            catch (Exception ex)
            {
                // Ghi log hoặc xử lý lỗi tùy ý
                throw new Exception($"Lỗi khi gửi transaction: {ex.Message}", ex);
            }
        }

        /// <summary>
        /// Lấy thông tin player từ blockchain theo địa chỉ ví
        /// </summary>
        public async Task<PlayerDTO> GetPlayerAsync(string playerAddress)
        {
            try
            {
                var contract = _web3.Eth.GetContract(ABI, _contractAddress);
                var getPlayerFunction = contract.GetFunction("getPlayer");

                var result = await getPlayerFunction.CallDeserializingToObjectAsync<PlayerDTO>(playerAddress);
                return result;
            }
            catch (Exception ex)
            {
                // Xử lý lỗi khi gọi hàm đọc
                throw new Exception($"Lỗi khi lấy thông tin player: {ex.Message}", ex);
            }
        }

        /// <summary>
        /// DTO để map dữ liệu trả về từ smart contract
        /// </summary>
        public class PlayerDTO
        {
            [Nethereum.ABI.FunctionEncoding.Attributes.Parameter("string", "username", 1)]
            public string Username { get; set; }

            [Nethereum.ABI.FunctionEncoding.Attributes.Parameter("uint256", "score", 2)]
            public BigInteger Score { get; set; }

            [Nethereum.ABI.FunctionEncoding.Attributes.Parameter("string", "rank", 3)]
            public string Rank { get; set; }
        }

        /// <summary>
        /// ABI contract đúng với smart contract của bạn
        /// </summary>
        private const string ABI = @"[
            {
              ""inputs"": [
                { ""internalType"": ""string"", ""name"": ""username"", ""type"": ""string"" },
                { ""internalType"": ""uint256"", ""name"": ""score"", ""type"": ""uint256"" },
                { ""internalType"": ""string"", ""name"": ""rank"", ""type"": ""string"" }
              ],
              ""name"": ""setPlayer"",
              ""outputs"": [],
              ""stateMutability"": ""nonpayable"",
              ""type"": ""function""
            },
            {
              ""inputs"": [
                { ""internalType"": ""address"", ""name"": ""playerAddress"", ""type"": ""address"" }
              ],
              ""name"": ""getPlayer"",
              ""outputs"": [
                { ""internalType"": ""string"", ""name"": ""username"", ""type"": ""string"" },
                { ""internalType"": ""uint256"", ""name"": ""score"", ""type"": ""uint256"" },
                { ""internalType"": ""string"", ""name"": ""rank"", ""type"": ""string"" }
              ],
              ""stateMutability"": ""view"",
              ""type"": ""function""
            }
          ]";
    }
}
