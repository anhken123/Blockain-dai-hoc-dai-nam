﻿using Microsoft.AspNetCore.Mvc;
using btlquiz.Data;
using btlquiz.Models;
using btlquiz.Services;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using btlquiz.Models;

namespace btlquiz.Controllers
{
    public class QuizController : Controller
    {
        private readonly BlockchainService _blockchainService;

        public QuizController()
        {
            _blockchainService = new BlockchainService();
        }

        // Hiển thị danh sách môn học để chọn
        public IActionResult SelectSubject()
        {
            var subjects = DataService.GetAllSubjects();
            return View(subjects);
        }

        // Hiển thị danh sách bài tập theo môn đã chọn, kèm theo check rank
        public IActionResult SelectLevel(string subject)
        {
            if (string.IsNullOrEmpty(subject))
                return RedirectToAction("SelectSubject");

            var quizzes = DataService.GetAllQuizzes()
                .Where(q => q.Subject == subject).ToList();

            var user = DataService.GetUser();

            // Lọc những bài tập user đủ rank mới được làm
            var allowedLevels = new List<string>();
            foreach (var quiz in quizzes)
            {
                if (IsRankSufficient(user.Rank, quiz.Level))
                {
                    allowedLevels.Add(quiz.Level);
                }
            }

            ViewBag.Subject = subject;
            ViewBag.AllowedLevels = allowedLevels;
            return View(quizzes);
        }

        // GET: Hiển thị câu hỏi bài tập theo môn và level
        [HttpGet]
        public IActionResult TakeQuiz(string subject, string level)
        {
            if (string.IsNullOrEmpty(subject) || string.IsNullOrEmpty(level))
                return RedirectToAction("SelectSubject");

            var quizzes = DataService.GetAllQuizzes();
            var quiz = quizzes.FirstOrDefault(q => q.Subject == subject && q.Level == level);

            if (quiz == null)
                return NotFound("Không tìm thấy bài tập.");

            var user = DataService.GetUser();

            if (!IsRankSufficient(user.Rank, level))
                return Content("Rank của bạn chưa đủ để làm bài tập này.");

            return View(quiz);
        }

        // POST: Nhận kết quả làm bài, tính điểm, cập nhật user và gửi lên blockchain
        [HttpPost]
        public async Task<IActionResult> TakeQuiz(string subject, string level, Dictionary<int, int> answers)
        {
            if (string.IsNullOrEmpty(subject) || string.IsNullOrEmpty(level))
                return RedirectToAction("SelectSubject");

            var quizzes = DataService.GetAllQuizzes();
            var quiz = quizzes.FirstOrDefault(q => q.Subject == subject && q.Level == level);

            if (quiz == null)
                return NotFound("Không tìm thấy bài tập.");

            var user = DataService.GetUser();

            if (!IsRankSufficient(user.Rank, level))
                return Content("Rank của bạn chưa đủ để làm bài tập này.");

            int score = 0;

            foreach (var q in quiz.Questions.Select((value, index) => new { value, index }))
            {
                if (answers != null && answers.ContainsKey(q.index) && answers[q.index] == q.value.CorrectIndex)
                    score++;
            }

            user.Score += score;
            user.Rank = CalculateRank(user.Score);
            DataService.SaveUser(user);

            var txHash = await _blockchainService.SetPlayerAsync(user.Username, user.Score, user.Rank);

            ViewBag.Message = $"Bạn làm đúng {score} trên {quiz.Questions.Count} câu.<br/>" +
                              $"Tổng điểm hiện tại: {user.Score}.<br/>" +
                              $"Rank hiện tại: {user.Rank}.<br/>" +
                              $"Giao dịch đã gửi lên blockchain, TxHash: {txHash}";

            ViewBag.UserScore = user.Score;
            ViewBag.UserRank = user.Rank;

            return View("QuizResult");
        }

        private bool IsRankSufficient(string userRank, string quizLevel)
        {
            var ranks = new Dictionary<string, int> { { "Bronze", 1 }, { "Silver", 2 }, { "Gold", 3 }, { "Platinum", 4 } };
            var levels = new Dictionary<string, int> { { "Easy", 1 }, { "Medium", 2 }, { "Hard", 3 } };

            int userRankValue = ranks.ContainsKey(userRank) ? ranks[userRank] : 0;
            int quizLevelValue = levels.ContainsKey(quizLevel) ? levels[quizLevel] : 0;

            return userRankValue >= quizLevelValue;
        }

        private string CalculateRank(int score)
        {
            if (score >= 80) return "Platinum";
            if (score >= 50) return "Gold";
            if (score >= 20) return "Silver";
            return "Bronze";
        }

        public IActionResult Subjects()
        {
            var subjects = DataService.GetAllSubjects();
            return View(subjects);
        }

        public IActionResult Quizzes(string subject)
        {
            if (string.IsNullOrEmpty(subject))
                return RedirectToAction("Subjects");

            var user = DataService.GetUser();
            var quizzes = DataService.GetAllQuizzes()
                        .Where(q => q.Subject == subject)
                        .OrderBy(q => LevelToInt(q.Level))
                        .ToList();

            var allowedDifficulties = GetAllowedDifficultiesByRank(user.Rank);
            var filteredQuizzes = quizzes
                .Where(q => allowedDifficulties.Contains(LevelToInt(q.Level)))
                .ToList();

            ViewBag.UserRank = user.Rank;
            ViewBag.Subject = subject;

            return View(filteredQuizzes);
        }

        [HttpPost]
        public IActionResult SubmitResult(string subject, int score)
        {
            var user = DataService.GetUser();

            if (score > user.Score)
            {
                user.Score = score;
                user.Rank = CalculateRank(score);
                DataService.SaveUser(user);

                // TODO: Gửi lên blockchain nếu cần
            }

            return RedirectToAction("Score");
        }

        public IActionResult Score()
        {
            var user = DataService.GetUser();
            return View(user);
        }

        private List<int> GetAllowedDifficultiesByRank(string rank)
        {
            switch (rank)
            {
                case "Platinum": return new List<int> { 1, 2, 3 };
                case "Gold": return new List<int> { 1, 2 };
                case "Silver": return new List<int> { 1 };
                default: return new List<int> { 1 }; // Bronze
            }
        }

        private int LevelToInt(string level)
        {
            return level switch
            {
                "Easy" => 1,
                "Medium" => 2,
                "Hard" => 3,
                _ => 0
            };
        }
    }
}
