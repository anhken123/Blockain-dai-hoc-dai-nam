﻿public class PlayerInputModel
{
    public string Username { get; set; }
    public int Score { get; set; }
    public string Rank { get; set; }
}
