﻿using System.Collections.Generic;

namespace btlquiz.Models
{
    public class Quiz
    {
        public string Subject { get; set; }
        public string Level { get; set; }
        public List<Question> Questions { get; set; }  // Không phải IEnumerable
    }


    public class QuizQuestion
    {
        public string Text { get; set; }
        public List<string> Options { get; set; }
        public int CorrectIndex { get; set; }
    }
}
