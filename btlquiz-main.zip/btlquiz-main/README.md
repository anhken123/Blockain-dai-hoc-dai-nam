# 🧠 BTLQuiz - Quiz Website with Blockchain Integration

BTLQuiz là một website trắc nghiệm được xây dựng bằng ASP.NET Core MVC, cho phép người dùng:
- Đăng ký / đăng nhập
- Làm bài trắc nghiệm theo nhiều môn học
- Tính điểm và phân hạng (Gold, Silver, Platinum)
- Lưu trữ điểm và hạng trên Blockchain (Ethereum)

## 🚀 Tính năng nổi bật

- ✅ Giao diện đẹp, dễ sử dụng
- ✅ Hỗ trợ nhiều môn học và cấp độ khó
- ✅ Hệ thống phân hạng mở khóa bài quiz nâng cao
- ✅ Lưu thông tin (username, điểm, hạng) lên blockchain
- ✅ Không dùng cơ sở dữ liệu SQL – lưu trữ bằng JSON file

## 🛠️ Công nghệ sử dụng

- ASP.NET Core MVC
- C#
- HTML/CSS
- JavaScript
- Metamask + Web3.js
- Solidity (Smart Contract)
- JSON File (dữ liệu người dùng và bài làm)

## 🧪 Cách chạy dự án

### 1. Clone dự án
```bash
git clone https://github.com/<ten-cua-ban>/btlquiz.git
cd btlquiz
btlquiz/
├── Controllers/
├── Models/
├── Views/
├── wwwroot/
├── Data/               # Dữ liệu JSON lưu người dùng, điểm
├── SmartContracts/     # ABI & địa chỉ contract
└── README.md
📬 Liên hệ
Tên: [Nguyễn Minh Đức]

Email: [Ngocmaiminhduc0603@gmail.com]
